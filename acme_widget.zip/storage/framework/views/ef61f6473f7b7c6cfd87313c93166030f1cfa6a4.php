<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    


                    <section>
                          
                          <div class="card-body">
                          <?php echo e(__('Product Lists')); ?>

                         </div>  
                    <?php if($products): ?>
                        <table class="table table-striped">
                        <thead>
                          <tr>
                            <th><?php echo e(__('Name')); ?> </th>
                            <th>Code</th>
                            <th>Price</th>
                            <th>Offer</th>
                            <th>Added/Updated</th>
                           
                            <th><?php echo e(__('Action')); ?></th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  

                          <tr>
                            <td><?php echo e($product->name); ?></td>
                           
                            <td><?php echo e($product->code); ?></td>
                             <td><?php echo e(__('$')); ?><?php echo e($product->price); ?></td>
                            <td><?php echo e(($product->offered == 1) ? 'Yes' : 'No'); ?></td>
                            <td><?php echo e(date('Y-m-d',strtotime($product->created_at))); ?></td>
                            
                            <td><input type="button" id="addToCart" onclick="return addToCart('<?php echo e($product->code); ?>')" class="btn btn-success btn-md" name="addToCart" value="Add"></td>
                          </tr>
                         
                      
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>

                      <?php else: ?>
                      <?php echo e(__('Products are Sold!')); ?>

                      <?php endif; ?>
                       <div class="group">
                           <ul>
                               <li>Order < $50 - Delivery $4.95</li>
                               <li>Order > $50 < $90 - Delivery $2.95</li>
                               <li>Order > $90 - Delivery FREE</li>
                           </ul>
                       </div>
                    </section>

                    <section class="basket">
                        <div class="card-body">
                          <h3>Cart:</h3>
                          <h5 align="right">Order Total: <b><?php echo e($sumOfPrices); ?></b>    </h5>
                          <h5 align="right">Delivery Cost: 
                            <b>
                                <?php if($sumOfPrices > 0 && $sumOfPrices < 50): ?>
                                 4.95
                                <?php endif; ?>
                                <?php if($sumOfPrices > 50 && $sumOfPrices < 90): ?>
                                 2.95
                                <?php endif; ?>
                                <?php if($sumOfPrices > 90): ?>
                                 FREE
                                <?php endif; ?>


                            </b>    
                          </h5>
                         </div>  
                        <?php if($cartData != null): ?>
                        <table class="table table-striped">
                        <thead>
                          <tr>
                           
                            <th>Code</th>
                            <th>Price</th>
                            
                            <th>Date</th>
                           
                            
                            
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cartData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                          <tr>
                            
                            <td><?php echo e($cart->code); ?></td>
                            <td><?php echo e($cart->price); ?></td>
                           
                            <td><?php echo e(date('Y-m-d',strtotime($cart->created_at))); ?></td>
                            
                            
                           
                          </tr>
                      
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>

                      <?php else: ?>
                      <?php echo e(__('Basket Empty!')); ?>

                      <?php endif; ?>
                    
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
   <script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>
<script type="text/javascript">
    
//     $(document).ready(function() {
//     $("#addToCart").click(function(){
    
//     var code  = $('#code').val();    
//     alert(code);


//     }); 
// });


    function addToCart(code) {
    

    $.ajax({
        type:"GET",
        cache:false,
        url:"<?php echo e(url('cart/add')); ?>/"+code,
        //data:code,    // multiple data sent using ajax
        success: function (html) {

            window.location.href = '<?php echo e(url('home')); ?>';
        }
      });
    





    }





</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\acme_widget\resources\views/home.blade.php ENDPATH**/ ?>